class Binding:
    def __init__(self, code=0, action=None):
        self.keyCode = code;
        self.action = action;

class Actions:
    def addLetter():
        pass;

    def removeLetter():
        pass;